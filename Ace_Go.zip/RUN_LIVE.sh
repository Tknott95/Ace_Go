# Shell Script for Live Deploy Run of Binary exec.

#!/bin/bash

# Assuming you already got project
cd $GOPATH/src/github.com/tknott95/Ace_Go/

./Ace_Go

