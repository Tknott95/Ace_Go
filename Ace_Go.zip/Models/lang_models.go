package Models

type Lang struct {
	ID       int
	LangName string
}
