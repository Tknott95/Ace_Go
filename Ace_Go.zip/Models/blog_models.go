package Models

type BlogPost struct {
	ID       int
	Title    string
	Image    string
	Category string
	Content  string
	Author   string
	Date     int
}
